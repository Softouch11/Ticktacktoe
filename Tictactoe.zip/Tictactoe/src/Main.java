import Controller.Controller;

public class Main{

        public Main() {
        }

        public static void main(String[] args){
                Controller j=new Controller();
        }

}

